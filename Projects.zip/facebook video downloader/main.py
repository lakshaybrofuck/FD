from flask import Flask, request, jsonify, render_template, send_file
import yt_dlp
import os
from flask_cors import CORS
import tempfile

app = Flask(__name__)
CORS(app)

# Store download progress and temporary file path
download_progress = {
    'status': '',
    'progress': 0,
    'filename': '',
    'temp_path': ''
}

def hook(d):
    if d['status'] == 'downloading':
        try:
            download_progress['progress'] = (d['downloaded_bytes'] / d['total_bytes']) * 100
        except ZeroDivisionError:
            download_progress['progress'] = 0
        download_progress['status'] = 'downloading'
    elif d['status'] == 'finished':
        download_progress['status'] = 'finished'
        download_progress['filename'] = d['filename']
        download_progress['temp_path'] = d['filename']
        download_progress['progress'] = 100

def download_facebook_video(url):
    try:
        # Create temporary directory for download
        temp_dir = tempfile.mkdtemp()
        
        ydl_opts = {
            'format': 'best',  # Get the best quality
            'outtmpl': os.path.join(temp_dir, '%(title)s.%(ext)s'),
            'progress_hooks': [hook],
            'ignoreerrors': True,
            'no_warnings': True,
            'merge_output_format': 'mp4',  # Force MP4 output
        }

        download_progress['progress'] = 0
        download_progress['status'] = 'starting'
        download_progress['filename'] = 'video.mp4'
        download_progress['temp_path'] = ''

        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            try:
                info = ydl.extract_info(url, download=True)
                # Get the actual downloaded file path
                if 'entries' in info:
                    # Playlist
                    info = info['entries'][0]
                
                filename = os.path.join(temp_dir, f"{info['title']}.mp4")
                if os.path.exists(filename):
                    download_progress['temp_path'] = filename
                    download_progress['filename'] = os.path.basename(filename)
                    return True, "Download completed successfully", filename
                else:
                    # Try to find any MP4 file in the temp directory
                    files = os.listdir(temp_dir)
                    mp4_files = [f for f in files if f.endswith('.mp4')]
                    if mp4_files:
                        filename = os.path.join(temp_dir, mp4_files[0])
                        download_progress['temp_path'] = filename
                        download_progress['filename'] = mp4_files[0]
                        return True, "Download completed successfully", filename
                    
                return False, "Downloaded file not found", None
            except Exception as e:
                return False, f"Invalid URL or video not accessible: {str(e)}", None
            
    except Exception as e:
        return False, f"Download failed: {str(e)}", None

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/download', methods=['POST'])
def download():
    data = request.get_json()
    url = data.get('url')
    
    if not url:
        return jsonify({'error': 'URL is required'}), 400

    success, message, filepath = download_facebook_video(url)
    
    if success:
        return jsonify({
            'status': 'success',
            'message': message,
            'filename': os.path.basename(filepath),
            'download_url': f'/get_file/{os.path.basename(filepath)}'
        })
    else:
        return jsonify({
            'status': 'error',
            'message': message
        }), 400

@app.route('/get_file/<filename>')
def get_file(filename):
    temp_path = download_progress['temp_path']
    if temp_path and os.path.exists(temp_path):
        try:
            return send_file(
                temp_path,
                as_attachment=True,
                download_name=filename,
                mimetype='video/mp4'
            )
        except Exception as e:
            return jsonify({'error': f'Error sending file: {str(e)}'}), 500
    return jsonify({'error': 'File not found'}), 404

@app.route('/progress')
def get_progress():
    return jsonify(download_progress)

if __name__ == '__main__':
    # Ensure templates directory exists
    if not os.path.exists('templates'):
        os.makedirs('templates')
    
    # Copy index.html to templates if it doesn't exist there
    if not os.path.exists('templates/index.html'):
        import shutil
        shutil.copy2('index.html', 'templates/index.html')
    
    app.run(debug=True, port=5000)
