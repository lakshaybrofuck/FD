import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox
from PIL import Image, ImageDraw, ImageGrab

class PaintApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Ultimate Paint App 🖌️")
        self.root.geometry("1000x700")
        self.root.configure(bg="white")
        
        self.brush_color = "black"
        self.eraser_on = False
        self.brush_size = 5
        self.bg_color = "white"
        self.last_x, self.last_y = None, None
        self.history = []
        self.redo_stack = []
        self.tool = "pencil"  # pencil, line, rect, oval

        self.canvas = tk.Canvas(root, bg=self.bg_color, width=800, height=600, cursor="cross")
        self.canvas.pack(pady=20)
        self.canvas.bind("<Button-1>", self.start_draw)
        self.canvas.bind("<B1-Motion>", self.draw)
        self.canvas.bind("<ButtonRelease-1>", self.reset_draw)

        self.setup_ui()
    
    def setup_ui(self):
        control_frame = tk.Frame(self.root, bg="lightgrey")
        control_frame.pack(fill=tk.X)

        tk.Label(control_frame, text="Brush Size:", bg="lightgrey").pack(side=tk.LEFT, padx=5)
        self.size_slider = tk.Scale(control_frame, from_=1, to=20, orient=tk.HORIZONTAL, command=self.change_brush_size)
        self.size_slider.set(self.brush_size)
        self.size_slider.pack(side=tk.LEFT)

        tk.Button(control_frame, text="Color", command=self.choose_color).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Eraser", command=self.use_eraser).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Clear", command=self.clear_canvas).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Save", command=self.save_image).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Undo", command=self.undo).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Redo", command=self.redo).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Fill BG", command=self.fill_background).pack(side=tk.LEFT, padx=5)

        tk.Label(control_frame, text="Tool:", bg="lightgrey").pack(side=tk.LEFT, padx=10)
        self.tool_var = tk.StringVar(value="pencil")
        for tool in ["pencil", "line", "rect", "oval"]:
            tk.Radiobutton(control_frame, text=tool.capitalize(), variable=self.tool_var, value=tool, command=self.select_tool, bg="lightgrey").pack(side=tk.LEFT)

    def change_brush_size(self, val):
        self.brush_size = int(val)

    def choose_color(self):
        color = colorchooser.askcolor()[1]
        if color:
            self.brush_color = color
            self.eraser_on = False

    def use_eraser(self):
        self.eraser_on = True

    def select_tool(self):
        self.tool = self.tool_var.get()
        self.eraser_on = False

    def start_draw(self, event):
        self.last_x, self.last_y = event.x, event.y
        self.start_x, self.start_y = event.x, event.y
        self.temp_shape = None

    def draw(self, event):
        color = self.bg_color if self.eraser_on else self.brush_color
        tool = self.tool_var.get()

        if tool == "pencil":
            self.canvas.create_line(self.last_x, self.last_y, event.x, event.y, width=self.brush_size, fill=color, capstyle=tk.ROUND, smooth=True)
            self.last_x, self.last_y = event.x, event.y
        else:
            if self.temp_shape:
                self.canvas.delete(self.temp_shape)

            if tool == "line":
                self.temp_shape = self.canvas.create_line(self.start_x, self.start_y, event.x, event.y, width=self.brush_size, fill=color)
            elif tool == "rect":
                self.temp_shape = self.canvas.create_rectangle(self.start_x, self.start_y, event.x, event.y, width=self.brush_size, outline=color)
            elif tool == "oval":
                self.temp_shape = self.canvas.create_oval(self.start_x, self.start_y, event.x, event.y, width=self.brush_size, outline=color)

    def reset_draw(self, event):
        if self.tool != "pencil" and self.temp_shape:
            self.history.append(self.canvas.create_line(0, 0, 0, 0))  # dummy to mark history
        self.save_state()

    def save_state(self):
        self.redo_stack.clear()
        ps = self.canvas.postscript(colormode='color')
        self.history.append(ps)
        if len(self.history) > 30:
            self.history.pop(0)

    def undo(self):
        if len(self.history) > 1:
            last = self.history.pop()
            self.redo_stack.append(last)
            self.redraw_canvas(self.history[-1])
        else:
            messagebox.showinfo("Info", "Nothing to undo")

    def redo(self):
        if self.redo_stack:
            state = self.redo_stack.pop()
            self.history.append(state)
            self.redraw_canvas(state)

    def redraw_canvas(self, postscript_data):
        self.canvas.delete("all")
        img = Image.open(filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG Files", "*.png")]))
        self.canvas.create_image(0, 0, image=img, anchor=tk.NW)

    def fill_background(self):
        color = colorchooser.askcolor()[1]
        if color:
            self.bg_color = color
            self.canvas.configure(bg=color)

    def clear_canvas(self):
        self.canvas.delete("all")
        self.history.clear()
        self.canvas.configure(bg=self.bg_color)

    def save_image(self):
        x = self.root.winfo_rootx() + self.canvas.winfo_x()
        y = self.root.winfo_rooty() + self.canvas.winfo_y()
        x1 = x + self.canvas.winfo_width()
        y1 = y + self.canvas.winfo_height()
        file = filedialog.asksaveasfilename(defaultextension=".png",
                                            filetypes=[("PNG files", "*.png")])
        if file:
            ImageGrab.grab().crop((x, y, x1, y1)).save(file)
            messagebox.showinfo("Saved", "Your masterpiece is saved! 🎨")

# Run the app
if __name__ == "__main__":
    root = tk.Tk()
    app = PaintApp(root)
    root.mainloop()
